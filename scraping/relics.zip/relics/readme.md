## <Scraping> Relics
A web scrapping program that gets the entire list of relics from Warframe's wiki. Fast and reliable way to get and format to a json file.