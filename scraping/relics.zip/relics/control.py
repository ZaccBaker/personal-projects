
from web.scrapper import RelicScrapper
from manager.data_manager import DataManager

class Control:
    def __init__(self):
        try:

            RelicScrapper()
            # DataManager(tables)

        except Exception as e:
            print(f"Exception thrown: {e}")