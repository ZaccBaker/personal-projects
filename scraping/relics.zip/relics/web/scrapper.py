import requests # Send HTTP requests to get web content
from bs4 import BeautifulSoup # Parse request



class RelicScrapper:
    def __init__(self):
        ADDRESS = "https://wiki.warframe.com/w/Void_Relic"
        WEB_RESPONSE = requests.get(ADDRESS)

        print(f"Status code : {WEB_RESPONSE.status_code}")
        # print(f"Content\n{WEB_RESPONSE.content}")

        soup = self.parse(WEB_RESPONSE)
        # print(self.reorder)

        content_div = self.find_content(soup)
        # print(content_div)

        tables = self.find_tables(content_div)
        # print(tables)

        # relics_array = self.find_relics(tables)
        # print(f"Relics Array : {relics_array}")
        
        # return relics_array

        
    def parse(self, response): # If you want to parse content
        soup = BeautifulSoup(response.content, 'html.parser')
        return soup


    def organize(self, response): # If you want pretty output
        soup = BeautifulSoup(response.content, 'html.parser')
        return soup.prettify()


    def find_content(self, soup_content : BeautifulSoup): # Find main content div
        # Website content div <class="mw-body-content">
        content = soup_content.find("div", class_="mw-body-content")
        return content
    

    def find_tables(self, content_div : BeautifulSoup) -> BeautifulSoup:  # Find tables with relics
        # Website relics are in <table>
        tables = content_div.find_all('table', class_="wikitable mw-collapsible")
        return tables
        
    
    # def find_relics(self, tables : BeautifulSoup) -> list: # Find relics, create masterlist
        
    #     relics_array = []

    #     for index, table in enumerate(tables, start=1):
    
    #         relic_items = table.find_all("li")

    #         for li in relic_items:
    #             relic_name = li.get_text(strip=True)
    #             relics_array.append(relic_name.replace('\u00A0', ' ').strip())
    #     return relics_array

    # def relics_dictonary(self, relics_array : list) -> dict: # Sort relics into dict
            
    #         relics_dict = {
    #             "Lith" : {},
    #             "Meso" : {},
    #             "Neo" : {},
    #             "Axi" : {},
    #             "Requiem" : {}
    #         }
            
    #         for relic in relics_array:
    #             pass