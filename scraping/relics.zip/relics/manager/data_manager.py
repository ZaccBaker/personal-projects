

class DataManager:
    def __init__(self, tables=None):
        
        relics_array = self.find_relics(tables)
        print(f"Relics Array : {relics_array}")


    def find_relics(self, tables) -> list: # Find relics, create masterlist
        
        relics_array = []

        for index, table in enumerate(tables, start=1):
    
            relic_items = table.find_all("li")

            for li in relic_items:
                relic_name = li.get_text(strip=True)
                relics_array.append(relic_name.replace('\u00A0', ' ').strip())
        return relics_array


    def relics_dictonary(self, relics_array : list) -> dict: # Sort relics into dict
            
            relics_dict = {
                "Lith" : {},
                "Meso" : {},
                "Neo" : {},
                "Axi" : {},
                "Requiem" : {}
            }
            
            for relic in relics_array:
                pass