
from control import Control

if __name__ == "__main__":
    Control()